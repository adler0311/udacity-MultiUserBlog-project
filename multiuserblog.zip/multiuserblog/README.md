#Multi User Blog
This project is for making Multi User Blog web app with applying `jinja2 library`, `Google app engine`, `Google database`, and `authentication functionality using hmac module'. This app is built in python code.

You can make your own id and not only post content but you can like posts except your, and comment on the post.

This app is deployed by Google appspot

##Quickstart
Just go to the below webpage.
[Multi User Blog](http://multiuserblog-147805.appspot.com/).

##How to Contribute
The full code is not on Github, because I have not solved security issue such as secret key or api key. ~~So, No way~~.

##License
Item Catalog Project is written by Wonho NA who is student of Udacity Full-stack nano degree course. and The contents of this repository arer covered under the MIT License.

